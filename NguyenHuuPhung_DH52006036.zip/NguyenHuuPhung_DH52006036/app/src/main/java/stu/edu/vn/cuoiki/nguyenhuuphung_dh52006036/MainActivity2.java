package stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.dao.DBHelper;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.model.SanPham;

public class MainActivity2 extends AppCompatActivity {
    EditText txtMasp,txtTensp,txtGiatien,txtNambaohanh;
    Button btnLuu;
    SanPham sp;
    DBHelper helper;

    int requestCode = 113, resultCode = 115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        addControls();

        // SỬA
        helper = new DBHelper(this);
        Intent myIntent = getIntent();
        sp = (SanPham) myIntent.getSerializableExtra("SUA");
        if(sp != null){
            xuLySua(sp);
        }
        /////// KẾT THÚC SỬA

        addEvents();
    }

    private void addControls() {
        txtMasp = findViewById(R.id.txtMasp);
        txtTensp = findViewById(R.id.txtTensp);
        txtGiatien = findViewById(R.id.txtGiatien);
        txtNambaohanh=findViewById(R.id.txtNambaohanh);
        btnLuu = findViewById(R.id.btnLuu);
        sp = null;
    }

    private void addEvents() {

        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xuLyLuu();
            }
        });

    }

    private void xuLyLuu(){
        if(sp == null){
            sp = new SanPham();
            sp.setMaSP(txtMasp.getText().toString());
            sp.setTenSP(txtTensp.getText().toString());
            sp.setGia(Float.parseFloat(txtGiatien.getText().toString()));
            sp.setNamBH(Integer.parseInt(txtNambaohanh.getText().toString()));
        }
        else {
            sp.setMaSP(txtMasp.getText().toString());
            sp.setTenSP(txtTensp.getText().toString());
            sp.setGia(Float.parseFloat(txtGiatien.getText().toString()));
            sp.setNamBH(Integer.parseInt(txtNambaohanh.getText().toString()));
            helper.updateSP(sp);
        }

        Intent intent = getIntent();
        intent.putExtra("TRA", sp);
        setResult(resultCode, intent);
        finish();
    }


    // SỬA
    private void xuLySua(SanPham s){
        txtMasp.setText(s.getMaSP());
        txtTensp.setText(s.getTenSP());
        txtGiatien.setText(String.valueOf(s.getGia()));
        txtNambaohanh.setText(String.valueOf(s.getNamBH()));
    }

}