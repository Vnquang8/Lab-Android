package stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.util.ArrayList;
import java.util.List;

import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.model.SanPham;

public class DBHelper extends SQLiteOpenHelper {
    public static class TABLE implements BaseColumns {
        public static final String TABLE_NAME = "SANPHAM";
        public static final String COLUMN_Ma = "masanpham";
        public static final String COLUMN_tensp = "tensanpham";
        public static final String COLUMN_giatien = "gia";
        public static final String COLUMN_nambaohanh = "nambaohanh";
    }

    private static final String DB_Name = "dbsanpham.sqlite";
    private static final int DB_Version = 1;

    public static final String SQL_Create_Table = "CREATE TABLE IF NOT EXISTS " + TABLE.TABLE_NAME + "("+
            TABLE.COLUMN_Ma + " VARCHAR(50) PRIMARY KEY, " + TABLE.COLUMN_tensp + " VARCHAR(50),"
            + TABLE.COLUMN_giatien + " VARCHAR(50)," + TABLE.COLUMN_nambaohanh + " INTEGER)";

    public  static  final String Drop_table = "DROP TABLE IF EXISTS " + TABLE.TABLE_NAME;

    public Cursor getData(String sql)
    {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }
    public boolean a;

    public DBHelper(Context context) {
        super(context, DB_Name, null, DB_Version);
    }

    Context context;


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_Create_Table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(Drop_table);
        onCreate(sqLiteDatabase);
    }

    public List<SanPham> getAllSanPham() {
        List<SanPham> listSP = new ArrayList<>();

        String[] projection = {
                TABLE.COLUMN_Ma,
                TABLE.COLUMN_tensp,
                TABLE.COLUMN_giatien,
                TABLE.COLUMN_nambaohanh
        };
        Cursor cursor = getReadableDatabase().query(
                TABLE.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );


        while (cursor.moveToNext()) {
            SanPham sp = new SanPham();
            sp.setMaSP(cursor.getString(cursor.getColumnIndexOrThrow(TABLE.COLUMN_Ma)));
            sp.setTenSP(cursor.getString(cursor.getColumnIndexOrThrow(TABLE.COLUMN_tensp)));
            String gt = cursor.getString(cursor.getColumnIndexOrThrow(TABLE.COLUMN_giatien));
            sp.setGia(Float.parseFloat(gt));
            sp.setNamBH(cursor.getInt(cursor.getColumnIndexOrThrow(TABLE.COLUMN_nambaohanh)));


            listSP.add(sp);
        }

        cursor.close();
        return listSP;
}


    public void insertMT(SanPham sp) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TABLE.COLUMN_Ma, sp.getMaSP());
        values.put(TABLE.COLUMN_tensp, sp.getTenSP());
        values.put(TABLE.COLUMN_giatien, sp.getGia());
        values.put(TABLE.COLUMN_nambaohanh, sp.getNamBH());

        // Thêm dữ liệu vào bảng
        long result = db.insert(TABLE.TABLE_NAME, null, values);
        db.close();
    }


    public void deleteSP(String ma)
    {
        String selection = TABLE.COLUMN_Ma + " = ?";
        String[] selectionArgs ={ma};
        int deleteRows = getWritableDatabase().delete(TABLE.TABLE_NAME, selection, selectionArgs);
    }


    public void updateSP(SanPham sp)
    {
        ContentValues values = new ContentValues();

        values.put(TABLE.COLUMN_Ma, sp.getMaSP());
        values.put(TABLE.COLUMN_tensp, sp.getTenSP());
        values.put(TABLE.COLUMN_giatien, sp.getGia());
        values.put(TABLE.COLUMN_nambaohanh, sp.getNamBH());

        String selection = TABLE.COLUMN_Ma + " =?";
        String[] selectionArgs = {sp.getMaSP() + ""};
        int updateRows=getWritableDatabase().update(TABLE.TABLE_NAME, values,selection,selectionArgs);
    }
    public void QueryData(String sql)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(sql);
    }


}
