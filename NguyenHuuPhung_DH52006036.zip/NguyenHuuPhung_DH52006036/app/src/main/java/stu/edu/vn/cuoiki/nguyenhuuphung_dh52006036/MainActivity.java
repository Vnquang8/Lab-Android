package stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.adapter.SanPhamAdapter;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.dao.DBHelper;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.model.SanPham;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton fabThem;
    ArrayAdapter<SanPham> adapter;
    ListView lv;
    SanPham sp;
    DBHelper helper;
    List<SanPham> list = new ArrayList<>();
    SQLiteDatabase myDB;

    int requestCode = 113, resultCode = 115;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();

        helper = new DBHelper(MainActivity.this);

        helper.QueryData(DBHelper.SQL_Create_Table);

        addEvents();
        showMayTinh();
    }
    private void addControls() {
        fabThem = findViewById(R.id.fabThem);
        lv = findViewById(R.id.lv);
    }
    private void addEvents() {
        fabThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivityForResult(intent, requestCode);
            }
        });

    }
    private void showMayTinh() {
        list = (ArrayList<SanPham>) helper.getAllSanPham();
        adapter = new SanPhamAdapter(
                MainActivity.this,
                R.layout.item,
                list,
                helper);
        lv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
    protected void onDestroy() {
        helper.close();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == this.requestCode && resultCode == this.resultCode && data != null && data.hasExtra("TRA")) {
            SanPham tra = (SanPham) data.getSerializableExtra("TRA");

            // THÊM
            SanPham findInList = getSanPhamByMaMay(tra.getMaSP());
            if(findInList == null){
                SanPham mt = new SanPham();
                mt.setMaSP(tra.getMaSP());
                mt.setTenSP(tra.getTenSP());
                mt.setGia(tra.getGia());
                mt.setNamBH(tra.getNamBH());
                helper.insertMT(mt);

            }
            // SỬA
            else{
                helper.updateSP(tra);
                list.clear();
            }

            showMayTinh();
        }

        sp = null;
    }
    public SanPham getSanPhamByMaMay(String ma) {
        for (SanPham sanpham : list) {
            if (sanpham.getMaSP().equals(ma)) {
                return sanpham;
            }
        }
        return null; // Trả về null nếu không tìm thấy
    }

    @Override
    protected void onResume() {
        super.onResume();
        showMayTinh();
    }
}