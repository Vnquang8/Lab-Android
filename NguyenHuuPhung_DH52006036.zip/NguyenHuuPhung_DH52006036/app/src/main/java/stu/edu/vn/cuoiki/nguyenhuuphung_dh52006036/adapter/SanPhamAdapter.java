package stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.List;

import androidx.appcompat.app.AlertDialog;

import java.util.List;

import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.MainActivity2;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.R;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.dao.DBHelper;
import stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.model.SanPham;

public class SanPhamAdapter extends ArrayAdapter<SanPham> {

    Activity context;
    int layout;
    List<SanPham> list;
    DBHelper helper;

    public SanPhamAdapter(Activity context, int layout, List<SanPham> list, DBHelper helper) {
        super(context, layout, list);
        this.context = context;
        this.layout = layout;
        this.list = list;
        this.helper = helper;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater myLayout = context.getLayoutInflater();
        View item = myLayout.inflate(layout, null);
        SanPham sp = list.get(position);        // lấy dữ liệu đc chọn ra

        TextView txtMasp, txtTensp, txtNambaohanh, txtGiatien;

        txtMasp = item.findViewById(R.id.txtMasp);
        txtTensp = item.findViewById(R.id.txtTensp);
        txtGiatien = item.findViewById(R.id.txtGiatien);
        txtNambaohanh = item.findViewById(R.id.txtNambaohanh);

        txtMasp.setText(sp.getMaSP());
        txtTensp.setText(sp.getTenSP());
        txtGiatien.setText(String.valueOf(sp.getGia()));
        txtNambaohanh.setText(String.valueOf(sp.getNamBH()));

        //Xóa
        LinearLayout itemLayout = item.findViewById(R.id.itemLayout);
        item.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Xử lý sự kiện long click ở đây, ví dụ: hiển thị Dialog xác nhận xóa
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Xác nhận xóa");
                builder.setMessage("Bạn có muốn xóa công việc này?");
                builder.setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        helper.deleteSP(sp.getMaSP());
                        list.remove(sp);
                        notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Hủy", null);
                builder.show();

                return true;
            }
        });


        // SỬA
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MainActivity2.class);
                intent.putExtra("SUA", sp);
                context.startActivity(intent);
            }
        });
        ///////// KẾT THÚC SỬA

        return item;

    }
}
