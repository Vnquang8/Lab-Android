package stu.edu.vn.cuoiki.nguyenhuuphung_dh52006036.model;

import java.io.Serializable;

public class SanPham implements Serializable {
    private String maSP;
    private String tenSP;
    private float gia;
    private int namBH;
    public SanPham(){

    }
    public SanPham(String maSP, String tenSP, float gia, int namBH) {
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.gia = gia;
        this.namBH = namBH;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public float getGia() {
        return gia;
    }

    public void setGia(float gia) {
        this.gia = gia;
    }

    public int getNamBH() {
        return namBH;
    }

    public void setNamBH(int namBH) {
        this.namBH = namBH;
    }
}
